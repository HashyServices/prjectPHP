<?php

	public function get_title($url){
		$str = file_get_contents($url);
		if(strlen($str)>0){
			$str = trim(preg_replace('/\s+/', ' ', $str));
			preg_match("/\<title\>(.*)\<\/title\>/i",$str,$title); 
			return $title[1];
		}
	}
	
$arrayPages = array();
					
	$q = $_REQUEST["q"];
	$found = false;
	$num = 0;
	$strArray = array();
	foreach($arrayPages as $pages){
		$contents = file_get_contents($pages);
		$pattern = preg_quote($q, '/');
		$pattern = "/^.*$pattern.*\$/m";
		if(preg_match_all($pattern, $contents, $matches)){

			if ($num == 0) 
				echo "<p style='font-weight:bold'>Recherche effectu�e:</p>";
				$num++;

		echo "<br>";
		echo "<a href='#' onclick='linkToFrame(\"$pages\")'>".get_title($pages)."</a>","<br>";
		
		echo implode("\n", $matches[0]);
		echo "<br>";
		
		$found = true;
	}
	}
	if(!$found)
	echo "Any result found!";

?>
