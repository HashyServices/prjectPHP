<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "WebsiteLanguage");

// Define URL
$http = (isset($_SERVER['HTTPS']) ? 'https' : 'http');
$http .="://".$_SERVER['HTTP_HOST'];
define("ROOT_PATH", "/WebsiteLanguagedev/");
define("ROOT_URL", $http."/WebsiteLanguagedev/");
