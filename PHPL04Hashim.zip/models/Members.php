<?php
class Member {
	private $member_id;
	private $member_name;
	private $member_type_id;
	private $member_address;
	private $member_city_id;
	private $member_phone;
	private $member_email;
	private $member_password;
	private $member_language_id;
	private $member_city_name;
	private $member_language_name;
	private $member_type_name;
	
	public function __construct($_member_name = NULL, $_member_type_id = NULL, $_member_address = NULL, $_member_city_id = NULL, $_member_phone = NULL, $_member_email = NULL, $_member_password = NULL, $_member_language_id = NULL) {
		$this->member_name = $_member_name;
		$this->member_type_id = $_member_type_id;
		$this->member_address = $_member_address;
		$this->member_city_id = $_member_city_id;
		$this->member_phone = $_member_phone;
		$this->member_email = $_member_email;
		$this->member_password = $_member_password;
		$this->member_language_id = $_member_language_id;
	}
	
	public function getMemberTypeName() {
		return $this->member_type_name;
	}
	public function getMemberId() {
		return $this->member_id;
	}
	public function getMemberName() {
		return $this->member_name;
	}
	public function getMemberTypeId() {
		return $this->member_type_id;
	}
	public function getMemberAddress() {
		return $this->member_address;
	}
	public function getMemberCityId() {
		return $this->member_city_id;
	}
	public function getMemberPhone() {
		return $this->member_phone;
	}
	public function getMemberEmail() {
		return $this->member_email;
	}
	public function getMemberPassword() {
		return $this->member_password;
	}
	public function getMemberLanguageId() {
		return $this->member_language_id;
	}
	public function getMemberCityName() {
		return $this->member_city_name;
	}
	public function getMemberLanguageName() {
		return $this->member_language_name;
	}
	public function setMemberName($_member_name) {
		$this->member_name = $_member_name;
	}
	public function setMemberAddress($_member_address) {
		$this->member_address = $_member_address;
	}
	public function setMemberCityId($_member_city_id) {
		$this->member_city_id = $_member_city_id;
	}
	public function setMemberPhone($_member_phone) {
		$this->member_phone = $_member_phone;
	}
	public function setMemberEmail($_member_email) {
		$this->member_email = $_member_email;
	}
	public function setMemberPassword($_member_password) {
		$this->member_password = $_member_password;
	}
	public function setMemberLanguageId($_member_language_id) {
		$this->member_language_id = $_member_language_id;
	}
	public function addMember($conn) {
		$query = "INSERT INTO members (
				member_name,
				member_type_id,
				member_address, 
				member_city_id, 
				member_phone,
				member_email, 
				member_password,
				member_language_id)
						VALUES (
				'$this->member_name',
				$this->member_type_id,
				'$this->member_address', 
				$this->member_city_id, 
				'$this->member_phone',
				'$this->member_email', 
				'$this->member_password',
				$this->member_language_id)";
		
		$result = $conn->exec ( $query );
	}
	public function validateMemberPassword($conn, $pass, $m_email) {
		$pre_query = "SELECT member_email, member_id, member_name, member_password FROM members WHERE member_email=:m_email";
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->BindValue ( ":m_email", $m_email );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		if (count ( $result ) > 0) {
			if ($result [0] ["member_password"] == $pass) {
				$this->member_name = $result [0] ["member_name"];
				$this->member_id = $result [0] ["member_id"];
				return true;
			}
		}
		return false;
	}
	public function getMemberInformation($conn, $member_id) {
		$pre_query = "SELECT member_name, member_email, member_address, member_phone, language_name, member_city_name, member_password 
				FROM members, languages, members_city 
				WHERE member_id = :m_id
				AND members.member_language_id = languages.language_id 
				AND members.member_city_id = members_city.member_city_id";
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->BindValue ( ":m_id", $member_id );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		
		if (count ( $result ) > 0) {
			$this->member_name = $result [0] ["member_name"];
			$this->member_email = $result [0] ["member_email"];
			$this->member_address = $result [0] ["member_address"];
			$this->member_phone = $result [0] ["member_phone"];
			$this->member_city_name = $result [0] ["member_city_name"];
			$this->member_language_name = $result [0] ["language_name"];
			$this->member_password = $result [0] ["member_password"];
		}
	}
	public function changeMemberInformation($conn, $member_id) {
		$m_name = $this->member_name;
		$m_address = $this->member_address;
		$m_city = $this->member_city_id;
		$m_phone = $this->member_phone;
		$m_password = $this->member_password;
		$m_language =  $this->member_language_id;
		
		$pre_query = "UPDATE  members SET member_name = '$m_name',  member_address = '$m_address', member_city_id = $m_city,  member_phone = '$m_phone', member_password = '$m_password', member_language_id = $m_language WHERE member_id = :m_id";
		
		$pre_query = $conn->prepare($pre_query);
		$pre_query->BindValue(":m_id", $member_id);
		$result = $pre_query->execute();
	}
	public function getAllMembers()
	{
		$pre_query = "SELECT member_id, member_type_name, member_name, member_email, member_address, member_phone, language_name, member_city_name, member_password 
				FROM members, languages, members_city, members_type
				WHERE member_id = :m_id
				AND members.member_language_id = languages.language_id 
				AND members.member_city_id = members_city.member_city_id
				AND members.member_type_id = members_type.member_type_id";
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->BindValue ( ":m_id", $member_id );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		$cpt=0;
		foreach ($result as $oneRec) {
			$mObj = new Member();
			$mObj->member_id = $oneRec["member_id"];
			$mObj->member_type_name = $oneRec["member_type_name"];
			$mObj->member_name = $oneRec["member_name"];
			$mObj->member_email = $oneRec ["member_email"];
			$mObj->member_address = $oneRec ["member_address"];
			$mObj->member_phone = $oneRec ["member_phone"];
			$mObj->member_city_name = $oneRec ["member_city_name"];
			$mObj->member_language_name = $oneRec ["language_name"];
			$mObj->member_password = $oneRec ["member_password"];
			$listOfMembers[$cpt++]=$mObj;
		}
		return $listOfMembers;
	}
	function getMembersCity($conn) {
		$query = "SELECT member_city_id,  member_city_name FROM members_city ";
	
		foreach ( $conn->query ( $query ) as $row ) {
			echo "<option value='" . $row ['member_city_id'] . "'>" . $row ['member_city_name'] . "</option>";
		}
	}
	function getMembersLanguage($conn) {
		$query = "SELECT language_id,  language_name FROM languages";
	
		foreach ( $conn->query ( $query ) as $row ) {
			echo "<option value='" . $row ['language_id'] . "'>" . $row ['language_name'] . "</option>";
		}
	}
	static function header(){
			
		echo "<table border = '1' cellspacing='0'>";
		echo "<tr>
				<th>Member id</th>
				<th>Member type</th>
				<th>Member name</th>
				<th>Member email</th>
				<th>Member address</th>
				<th>Member phone</th>
				<th>Member city</th>
				<th>Member language</th>
				<th>Member password</th></tr>";
	}
	
	static function footer(){
		echo "</table>";
	}
	static function displayMembers($listOfMembers){
	
		self::header();
		foreach ($listOfMembers as $oneMember)
			echo $oneMember;
			self::footer();
	
	}
	public function __toString() {
		return "<tr>
				<td>".$this->member_id."</td>
				<td>".$this->member_type_name."</td>
				<td>".$this->member_name."</td>
				<td>".$this->member_email."</td>
				<td>".$this->member_address."</td>
				<td>".$this->member_phone."</td>
				<td>".$this->member_city_name."</td>
				<td>".$this->member_language_name."</td>
				<td>".$this->member_password."</td></tr>";
	}
}

?>