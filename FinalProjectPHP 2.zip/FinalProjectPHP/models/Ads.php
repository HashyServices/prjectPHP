<?php
class Ads {
	private $ad_id;
	private $ad_subcategory_id;
	private $ad_title;
	private $ad_content;
	private $ad_start_date;
	private $ad_status;
	private $ad_type_id;
	private $ad_member_id;
	private $ad_album_id;
	private $duration;
	private $ad_subcategory_name;
	private $ad_member_name;
	private $ad_member_phone;
	private $ad_member_email;
	
	public function __construct( $_ad_subcategory_id = NULL, $_ad_title = NULL, $_ad_content = NULL, $_ad_start_date = NULL, $_ad_status = NULL, $_ad_type_id = NULL, $_ad_member_id = NULL, $_ad_album_id = NULL) {
		$this->ad_subcategory_id = $_ad_subcategory_id;
		$this->ad_title = $_ad_title;
		$this->ad_content = $_ad_content;
		$this->ad_start_date = $_ad_start_date;
		$this->ad_status = $_ad_status;
		$this->ad_type_id = $_ad_type_id;
		$this->ad_member_id = $_ad_member_id;
		$this->ad_album_id = $_ad_album_id;
	}

	public function getAdMemberPhone()
	{
		return $this->ad_member_phone;
	}
	public function getAdMemberEmail()
	{
		return $this->ad_member_email;
	}
	public function getAdMemberName()
	{
		return $this->ad_member_name;
	}
	public function getAdSubcategoryName() {
		return $this->ad_subcategory_name;
	}
	public function getDuration() {
		return $this->duration;
	}
	public function getAdId() {
		return $this->ad_id;
	}
	
	public function getAdSubcategoryId() {
		return $this->ad_subcategory_id;
	}
	public function setAdSubcategoryId($_ad_subcategory_id) {
		$this->ad_subcategory_id = $_ad_subcategory_id;
	}
	
	public function getAdTitle() {
		return $this->ad_title;
	}
	public function setAdTitle($_ad_title) {
		$this->ad_title = $_ad_title;
	}
	
	public function getAdContent() {
		return $this->ad_content;
	}
	public function setAdContent($_ad_content) {
		$this->ad_content = $_ad_content;
	}
	
	public function getAdStartDate() {
		return $this->ad_start_date;
	}
	public function setAdStartDate($_ad_start_date) {
		$this->ad_start_date = $_ad_start_date;
	}
	
	public function getAdStatus() {
		return $this->ad_status;
	}
	public function setAdStatus($_ad_status) {
		$this->ad_status = $_ad_status;
	}
	
	public function getAdTypeId() {
		return $this->ad_type_id;
	}
	public function setAdTypeId($_ad_type_id) {
		 $this->ad_type_id = $_ad_type_id;
	}
	
	public function getAdMemberId() {
		return $this->ad_member_id;
	}
	public function setAdMemberId($_ad_member_id) {
		$this->ad_member_id = $_ad_member_id;
	}
	
	public function getAdAlbumId() {
		return $this->ad_album_id;
	}
	public function setAdAlbumId($_ad_album_id) {
		$this->ad_album_id = $_ad_album_id;
	}
	public function addAd($conn) {
		
		/*
		echo "Ads.cls"."<br />";
		echo "Sub: ".$this->ad_subcategory_id."<br />";
		echo "Title: ".$this->ad_title."<br />";
		echo "Content: ".$this->ad_content."<br />";
		echo "Start: ".$this->ad_start_date."<br />";
		echo "Type: ".$this->ad_type_id."<br />";
		echo "us id: ".$this->ad_member_id."<br />";
		echo "al id: ".$this->ad_album_id."<br />";
		
		*/
		/*$query = "INSERT INTO advertisings (
				ad_subcategory_id,
				ad_title,
				ad_content, 
				ad_start_date, 
				ad_status,
				ad_type_id, 
				ad_member_id,
				ad_album_id)
						VALUES (
				$this->ad_subcategory_id,
				'$this->ad_title',
				'$this->ad_content', 
				'$this->ad_start_date', 
				$this->ad_status,
				$this->ad_type_id, 
				$this->ad_member_id,
				$this->ad_album_id)";*/
		$query = "INSERT INTO advertisings (
		ad_subcategory_id,
		ad_title,
		ad_content,
		ad_start_date,
		ad_status,
		ad_type_id,
		ad_member_id)
		VALUES (
		$this->ad_subcategory_id,
		'$this->ad_title',
		'$this->ad_content',
		'$this->ad_start_date',
		$this->ad_status,
		$this->ad_type_id,
		$this->ad_member_id)";
		
		$result = $conn->exec ( $query );
	}
	public function getAdInformation($conn, $ad_id) {
		$pre_query = "SELECT  ad_id, subcategory_name, ad_title, ad_content, ad_start_date, ad_status, duration, member_name, member_phone, member_email
				FROM advertisings, members, subcategories_names, advertisings_types 
				WHERE advertisings.ad_subcategory_id = subcategories_names.subcategory_id 
				AND advertisings.ad_type_id = advertisings_types.type_id 
				AND advertisings.ad_member_id = members.member_id
				AND ad_id = :ad_id";
		
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->BindValue ( ":ad_id", $ad_id );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		
		if (count ( $result ) > 0) {
			$this->ad_id = $result [0] ["ad_id"];
			$this->ad_subcategory_name = $result [0] ["subcategory_name"];
			$this->ad_title = $result [0] ["ad_title"];
			$this->ad_content = $result [0] ["ad_content"];
			$this->ad_start_date = $result [0] ["ad_start_date"];
			$this->ad_status = $result [0] ["ad_status"];
			$this->duration = $result [0] ["duration"];
			$this->ad_member_name = $result [0] ["member_name"];
			$this->ad_member_phone = $result [0] ["member_phone"];
			$this->ad_member_email = $result [0] ["member_email"];
		}
	}

	public function getAllAds($conn)
	{
		$listOfAds = array();
		$pre_query = "SELECT ad_id, subcategory_name, ad_title, ad_content, ad_start_date, ad_status, duration, member_name
				FROM advertisings, members, subcategories_names, advertisings_types 
				WHERE advertisings.ad_subcategory_id = subcategories_names.subcategory_id 
				AND advertisings.ad_type_id = advertisings_types.type_id 
				AND advertisings.ad_member_id = members.member_id";
		
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		$cpt=0;
		foreach ($result as $oneRec) {
			$aObj = new Ads();
			$aObj->ad_id = $oneRec["ad_id"];
			$aObj->ad_subcategory_name = $oneRec["subcategory_name"];
			$aObj->ad_title = $oneRec["ad_title"];
			$aObj->ad_content = $oneRec ["ad_content"];
			$aObj->ad_start_date = $oneRec ["ad_start_date"];
			$aObj->ad_status = $oneRec ["ad_status"];
			$aObj->duration =$oneRec ["duration"];
			$aObj->ad_member_name = $oneRec ["member_name"];
			$listOfAds[$cpt++]=$aObj;
		}
		return $listOfAds;
	}
	
	public function getPayebleAds($conn)
	{
		$listOfAds = array();
		$pre_query = "SELECT ad_id, subcategory_name, ad_title, ad_content, ad_start_date, ad_status, duration, member_name
				FROM advertisings, members, subcategories_names, advertisings_types
				WHERE advertisings.ad_subcategory_id = subcategories_names.subcategory_id
				AND advertisings.ad_type_id = advertisings_types.type_id
				AND advertisings.ad_member_id = members.member_id
				AND advertisings_types.type_id != 1";
	
		$pre_query = $conn->prepare ( $pre_query );
		$pre_query->execute ();
		$result = $pre_query->fetchAll ();
		$cpt=0;
		foreach ($result as $oneRec) {
			$aObj = new Ads();
			$aObj->ad_id = $oneRec["ad_id"];
			$aObj->ad_subcategory_name = $oneRec["subcategory_name"];
			$aObj->ad_title = $oneRec["ad_title"];
			$aObj->ad_content = $oneRec ["ad_content"];
			$aObj->ad_start_date = $oneRec ["ad_start_date"];
			$aObj->ad_status = $oneRec ["ad_status"];
			$aObj->duration =$oneRec ["duration"];
			$aObj->ad_member_name = $oneRec ["member_name"];
			$listOfAds[$cpt++]=$aObj;
		}
		return $listOfAds;
	}
	function displayAdsDiv($listOfAds){
		foreach ($listOfAds as $oneAd)
		{
			echo "<a href='ad_info_form.php?selected_ad_id=".$oneAd->getAdId()."'>
		 <div id='ad_div'><img id='title_image' src='../IMG/empty_gallery_small.png' alt='ad image' class='inner_link_img'>
		 <b><p id='title_name'>".$oneAd->getAdTitle()."</p></b></div></a>";
		}
	}
	function getAdsCategory($conn) {
		$query = "SELECT * FROM categories_names";
		foreach ($conn->query($query) as $row) {
			echo "<option value='" . $row ['category_id'] . "'>" . utf8_encode ($row ['category_name']) . "</option>";
		}
	}
	function getAdsSubcategory($conn) {
		$query = "SELECT * FROM subcategories, subcategories_names, categories_names WHERE subcategories_names.subcategory_id = subcategories.subcategory_id AND subcategories.category_id = categories_names.category_id";
		foreach ($conn->query($query) as $row) {
			echo "<option value='" . $row ['subcategory_id'] . "'>" . utf8_encode ($row ['subcategory_name']) . "</option>";
		}
	}
	function getAdsType($conn) {
		$query = "SELECT * FROM advertisings_types";
	
		foreach ( $conn->query ( $query ) as $row ) {
			echo "<option value='" . $row ['type_id'] . "'>Duration " . $row ['duration'] ." days (".$row ['price'] ."$)". "</option>";
		}
	}

	static function header(){		
		echo "<table border = '1' cellspacing='0'>";
		echo "<tr>
				<th>Ad id</th>
				<th>Ad subcategory</th>
				<th>Ad title</th>
				<th>Ad content</th>
				<th>Ad start date</th>
				<th>Ad status</th>
				<th>Ad type name</th>
				<th>Member name</th></tr>";
	}
	
	static function footer(){
		echo "</table>";
	}
	static function displayMembers($listOfMembers){
	
		self::header();
		foreach ($listOfMembers as $oneMember)
			echo $oneMember;
			self::footer();
	
	}
	public function __toString() {
		return "<tr>
				<td>".$this->ad_id."</td>
				<td>".utf8_encode($this->ad_subcategory_name)."</td>
				<td>".utf8_encode($this->ad_title)."</td>
				<td>".utf8_encode($this->ad_content)."</td>
				<td>".$this->ad_start_date."</td>
				<td>".$this->ad_status."</td>
				<td>".$this->duration."</td>
				<td>".utf8_encode($this->ad_member_name)."</td></tr>";
	}
}

?>