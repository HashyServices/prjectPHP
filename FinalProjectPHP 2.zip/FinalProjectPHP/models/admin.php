<?php
class Admin extends Member
{
	private static $member_type_id = 2;
	public function __construct($_member_name = NULL, $_member_address = NULL, $_member_city_id = NULL, $_member_phone = NULL, $_member_email = NULL, $_member_password = NULL, $_member_language_id = NULL) 
	{
			parent::__construct($_member_name, self::$member_type_id, $_member_address , $_member_city_id, $_member_phone, $_member_email, $_member_password, $_member_language_id);		
	}
	
	public function deleteMember($conn, $member_id)
	{
		$pre_query = "DELETE FROM members WHERE member_id:m_id";
		$pre_query = $conn->prepare($pre_query);
		$pre_query->BindValue(":m_id", $member_id);
		$result = $pre_query->execute();
	}
}
?>