<?php
function getCityList($conn) {
	$query = "SELECT * FROM members_city";
	foreach ($conn->query($query) as $row) {
		echo "<option value='" . $row ['member_city_id'] . "'>" . utf8_encode ($row ['member_city_name']) . "</option>";
	}
}
?>